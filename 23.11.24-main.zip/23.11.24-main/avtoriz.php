<?php
function loginUser($email, $password) {
    global $pdo;

    // Получение пользователя по email
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    
    if ($stmt->rowCount() === 0) {
        return "Пользователь не найден.";
    }

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Проверка пароля
    if (password_verify($password, $user['password'])) {
        // Успешная авторизация
        session_start();
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];
        return "Авторизация успешна!";
    } else {
        return "Неверный пароль.";
    }
}
?>