<?php
function updateUser($id, $username, $email, $newPassword = null) {
    global $pdo;

    // Проверка уникальности email
    if ($newPassword !== null) {
        // Хеширование нового пароля
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, password = ? WHERE id = ?");
        return $stmt->execute([$username, $email, $hashedPassword, $id]);
        
    } else {
        // Обновление без изменения пароля
        $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
        return $stmt->execute([$username, $email, $id]);
    }
}
?>