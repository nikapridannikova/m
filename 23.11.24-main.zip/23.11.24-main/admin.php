<?php
function getAllUsers() {
    global $pdo;

    // Проверка роли администратора
    if ($_SESSION['role'] !== 'admin') {
        return "У вас нет доступа к этой функции.";
    }

    // Получение всех пользователей
    $stmt = $pdo->query("SELECT username, email FROM users");
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>